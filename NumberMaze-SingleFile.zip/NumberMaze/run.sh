#!/bin/sh
# เล่นเกม Number Maze บน macOS / Linux (ต้องมี Java 17 ขึ้นไป)
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
    echo "ไม่พบ Java ในเครื่องนี้ กรุณาติดตั้ง JDK 17 ขึ้นไปจาก https://adoptium.net"
    exit 1
fi
exec java -Dfile.encoding=UTF-8 NumberMaze.java
