เขาวงกตตัวเลข (Number Maze)
ผู้จัดทำ: 6804062611033 นายวัชรเศรษฐ์ ว่องรัตน์วานิช

วิธีเล่น
  1. แตกไฟล์ zip นี้ก่อน (คลิกขวา > Extract All) ห้ามดับเบิลคลิกจากในไฟล์ zip โดยตรง
  2. Windows: ดับเบิลคลิก run.bat
     macOS / Linux: เปิด Terminal ในโฟลเดอร์นี้แล้วพิมพ์  sh run.sh
  3. หรือรันเองด้วยคำสั่ง:  java -Dfile.encoding=UTF-8 NumberMaze.java

ต้องมี Java (JDK) 17 ขึ้นไป ดาวน์โหลดได้ที่ https://adoptium.net

ไฟล์ในโฟลเดอร์นี้
  NumberMaze.java  โค้ดเกมทั้งหมด 20 คลาสในไฟล์เดียว
  images\          รูปภาพในเกม (ต้องอยู่ข้างไฟล์ NumberMaze.java)
  run.bat / run.sh ไฟล์สำหรับเปิดเกม

ปุ่มควบคุม: W A S D หรือลูกศร = เดิน,  R = เริ่มด่านใหม่,  Enter = เล่นใหม่หลังจบเกม
