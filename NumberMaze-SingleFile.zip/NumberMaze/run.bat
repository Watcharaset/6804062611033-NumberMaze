@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM ============================================================
REM  ดับเบิลคลิกไฟล์นี้เพื่อเล่นเกม Number Maze (ต้องมี Java 17 ขึ้นไป)
REM ============================================================
where java >nul 2>nul
if errorlevel 1 (
    echo ไม่พบ Java ในเครื่องนี้
    echo กรุณาติดตั้ง JDK 17 ขึ้นไปจาก https://adoptium.net แล้วลองใหม่
    pause
    exit /b 1
)
echo กำลังเปิดเกม Number Maze... (ปิดหน้าต่างนี้ได้หลังเล่นเสร็จ)
java -Dfile.encoding=UTF-8 NumberMaze.java
if errorlevel 1 (
    echo.
    echo เปิดเกมไม่สำเร็จ ดูข้อความ error ด้านบน
    echo ถ้าเป็น error เกี่ยวกับเวอร์ชัน ให้ติดตั้ง JDK 17 ขึ้นไปจาก https://adoptium.net
    pause
)
